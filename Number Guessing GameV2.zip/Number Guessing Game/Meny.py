import time
from subprocess import call

def choose_English_file():
    call(["python", "NGG_English.py"])

def choose_Norsk_file():
    call(["python", "NGG_Norsk.py"])

menu_options = ("N", "E")

while True:
    print("Choose a your language")
    print("N = Norsk")
    print("E = English\n")

    user_input = input("\nEnter an option: ").upper()

    if user_input in menu_options:
        break

    else:
        print("\nOption not available")

if user_input == "E":
        print("\nProcessing... ")
        time.sleep(3)
        choose_English_file()

if user_input == "N":
    print("\nProcessing... ")
    time.sleep(3)
    choose_Norsk_file()
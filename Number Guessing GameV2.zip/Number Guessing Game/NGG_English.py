import random
import time
def hent_input(text):
    value = input(text)
    while not value.isnumeric():
        print("You have to write a positive number. ")
        value = input(text)
    return int(value)

while True:
    print("\nWelcome to The Number Guessing Game! ")






    print("\nYou have to choose a range of positive numbers to guess from.")
    min_number = hent_input("What should the minimum number be? ")
    max_number = hent_input("What should the maximum number be? ")

    while max_number <= min_number:
        print("\nThe maximum number has to be grater than the minimum number.")
        min_number = hent_input("What should the minimum number be? ")
        max_number = hent_input("What should the maximum number be? ")


    random_number = random.randint(min_number, max_number)
    number_guessed = hent_input("\nGuess the number! ")


    guesses = 0


    while True:
        guesses += 1

        if number_guessed > max_number:
            print(f"\nYour guess has to be lower than {max_number}")
            number_guessed = hent_input("Make another guess: ")
            continue

        if number_guessed < min_number:
            print(f"\nYour guess has to be greater than {min_number}")
            number_guessed = hent_input("Make another guess: ")
            continue

        if number_guessed > random_number:
            print("You are over the number.")
            number_guessed = hent_input("\nGuess again: ")
            continue

        if number_guessed < random_number:
            print("You are under the number.")
            number_guessed = hent_input("\nGuess again: ")
            continue
        break


    print(f"\nYou got it! The number was: {random_number}")
    print(f"You guessed {guesses} times before you got it right.")

    quit_status = input("\nPress Enter to continue or Q to quit: ").upper()

    if quit_status == ("Q"):
        break

import random
import time
def hent_input(text):
    value = input(text)
    while not value.isnumeric():
        print("Du må skrive et positivt tall.  ")
        value = input(text)
    return int(value)

while True:
    print("\nVelkommen til tall gjettings spillet!  ")

    print("\nDu må velge en rekke tall å gjette fra.")
    min_number = hent_input("Hva bør minimumsantallet være? ")
    max_number = hent_input("Hva bør maksimaltallet være? ")

    while max_number <= min_number:
        print("\nMaksimumsantallet må være større enn minimumsantallet.")
        min_number = hent_input("Hva bør minimumsantallet være? ")
        max_number = hent_input("Hva bør maksimaltallet være? ")


    random_number = random.randint(min_number, max_number)
    number_guessed = hent_input("\nGjett tallet! ")


    guesses = 0


    while True:
        guesses += 1

        if number_guessed > max_number:
            print(f"\nGjettet ditt må være lavere enn {max_number}")
            number_guessed = hent_input("Gjett igjen: ")
            continue

        if number_guessed < min_number:
            print(f"\nGjettet ditt må være høyere enn {min_number}")
            number_guessed = hent_input("Gjett igjen: ")
            continue

        if number_guessed > random_number:
            print("Du ligger over tallet")
            number_guessed = hent_input("\nGjett igjen: ")
            continue

        if number_guessed < random_number:
            print("Du ligger under tallet")
            number_guessed = hent_input("\nGjett igjen: ")
            continue
        break


    print(f"\nDu klarte det! Tallet var: {random_number}")
    print(f"Du gjettet {guesses} ganger før du klarte det.")

    quit_status = input("\nTrykk Enter for å fortsette eller Q for å avslutte ").upper()

    if quit_status == ("Q"):
        break
